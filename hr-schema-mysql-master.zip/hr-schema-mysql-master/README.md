# hr-schema-mysql
DML and DDL scripts to generate the HR SQL Schema for MySQL
